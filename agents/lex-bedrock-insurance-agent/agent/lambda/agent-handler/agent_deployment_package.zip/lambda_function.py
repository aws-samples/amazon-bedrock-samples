import os
import re
import json
import time
import boto3
import base64

from boto3.session import Session
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
from botocore.credentials import Credentials
from requests import request

def sigv4_request(
    url,
    method='GET',
    body=None,
    params=None,
    headers=None,
    service='execute-api',
    region=os.environ['AWS_REGION'],
    credentials=Session().get_credentials().get_frozen_credentials()
):
    """Sends an HTTP request signed with SigV4
    Args:
    url: The request URL (e.g. 'https://www.example.com').
    method: The request method (e.g. 'GET', 'POST', 'PUT', 'DELETE'). Defaults to 'GET'.
    body: The request body (e.g. json.dumps({ 'foo': 'bar' })). Defaults to None.
    params: The request query params (e.g. { 'foo': 'bar' }). Defaults to None.
    headers: The request headers (e.g. { 'content-type': 'application/json' }). Defaults to None.
    service: The AWS service name. Defaults to 'execute-api'.
    region: The AWS region id. Defaults to the env var 'AWS_REGION'.
    credentials: The AWS credentials. Defaults to the current boto3 session's credentials.
    Returns:
     The HTTP response
    """

    # sign request
    req = AWSRequest(
        method=method,
        url=url,
        data=body,
        params=params,
        headers=headers
    )
    SigV4Auth(credentials, service, region).add_auth(req)
    req = req.prepare()

    # send request
    return request(
        method=req.method,
        url=req.url,
        headers=req.headers,
        data=req.body
    )

def bedrock_agent(intent_request):
    query = intent_request["inputTranscript"].title()
    print("bedrock_agent query: " + query)
    
    if not query:
        message = {
            'contentType': 'PlainText',
            'content': 'utterance is empty, try again please'
        }
       
        intent_request['sessionState']['intent']['state'] = "Fulfilled"
        return {
            'sessionState': {
                'dialogAction': {
                    'type': 'ElicitIntent'
                },
                'intent': intent_request['sessionState']['intent']
            },
            'messages': [message],
            'sessionId': intent_request['sessionId'],
            'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
        }

    # Define the required parameters
    agentId = "OXI4KB2UUM"
    agentAliasId = "AUHPBVDTTQ"
    sessionId = intent_request["sessionId"]
    knowledgeBaseId = "YRVC7YMSXF"
    dataSourceId = "SV1BTJKPTA"

    # agents = bedrock-agent-runtime.us-east-1.amazonaws.com
    # knowledgebases = bedrock-agent.us-east-1.amazonaws.com
    url = f'https://bedrock-agent-runtime.us-east-1.amazonaws.com/agents/{agentId}/agentAliases/{agentAliasId}/sessions/{sessionId}/text'

    myobj = {
        "inputText": query,   
        "enableTrace": True,
    }

    # send request
    print("Calling sigv4_request")
    response = sigv4_request(
        url,
        method='POST',
        service='bedrock',
        headers={
            'content-type': 'application/json', 
            'accept': 'application/json',
        },
        region='us-east-1',
        body=json.dumps(myobj)
    )
    print("sig4_request response = " + response.text)
    
    # do something with response
    string = ""
    for line in response.iter_content():
        try:
            string += line.decode(encoding='utf-8')
        except:
            continue
    print("Decoded response", string)

    split_response = string.split(":message-type")
    last_response = split_response[-1]
    if "bytes" in last_response:
        encoded_last_response = last_response.split("\"")[3]
        decoded = base64.b64decode(encoded_last_response)
        final_response = decoded.decode('utf-8')
    else:
        part1 = string[string.find('finalResponse')+len('finalResponse":'):] 
        part2 = part1[:part1.find('"}')+2]
        final_response = json.loads(part2)['text']

    final_response = final_response.replace("\"", "")
    final_response = final_response.replace("{input:{value:", "")
    final_response = final_response.replace(",source:null}}", "")
    llm_response = final_response
    print("llm_response:: " + llm_response)

    message = {
        'contentType': 'PlainText',
        'content': llm_response
    }
   
    intent_request['sessionState']['intent']['state'] = "Fulfilled"
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'ElicitIntent'
            },
            'intent': intent_request['sessionState']['intent']
        },
        'messages': [message],
        'sessionId': intent_request['sessionId'],
        'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
    }

def dispatch(intent_request):
    #Routes the incoming request based on intent.
    slots = intent_request['sessionState']['intent']['slots']
    username = slots['UserName'] if 'UserName' in slots else None
    intent_name = intent_request['sessionState']['intent']['name']

    if intent_name == 'WelcomeIntent':
        return
    else:
        return bedrock_agent(intent_request)

# --- Main handler ---

def handler(event, context):
    """
    Invoked when the user provides an utterance that maps to a Lex bot intent.
    The JSON body of the user request is provided in the event slot.
    """
    os.environ['TZ'] = 'America/New_York'
    time.tzset()

    return dispatch(event)
