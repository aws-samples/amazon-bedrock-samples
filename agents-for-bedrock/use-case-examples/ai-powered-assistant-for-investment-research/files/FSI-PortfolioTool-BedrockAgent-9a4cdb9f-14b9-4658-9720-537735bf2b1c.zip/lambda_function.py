import pandas as pd
import datetime
import boto3
import os
import logging
from functools import reduce
from pypfopt.efficient_frontier import EfficientFrontier
from pypfopt import risk_models
from pypfopt import expected_returns
from typing import Optional
from typing import List, Optional
import json
from pyathena import connect

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    
    logger.info(event)
    api_path = event['apiPath']
    logger.info('API Path')
    logger.info(api_path)
    event['requestBody']['content']['application/json']['properties']
    
    textInput = ""
    
    if api_path == '/portfolio_tool':
        textInput = event['requestBody']['content']['application/json']['properties'][0]['value']
    else:
        textInput = ""
    
    logger.info(textInput)
    
    with open ('param.json','r') as f:
        params=json.load(f)

    region=params['region']
    table = 'stock_prices'
    glue_db_name=params['db']
    query_staging_bucket=os.getenv("QUERY_BUCKET")

     # Establish connection to Athena
    session = boto3.Session(region_name=region)
    athena_client = session.client('athena')

    stock_seq = textInput
    # Execute query
    # stock_seq = ''
    #for stock in textInput:
    #    print( stock)
    #    if stock_seq == '':
    #        stock_seq = stock
    #    else:
    #        stock_seq = stock_seq + ', ' + stock

    #print(stock_seq)

    query = f'SELECT date, {stock_seq} from "{glue_db_name}"."{table}"'
    print (f'query:{query}')
    cursor = connect(s3_staging_dir=f's3://{query_staging_bucket}/athenaresults/', region_name=region).cursor()
    cursor.execute(query)
    
    # Fetch results
    rows = cursor.fetchall()

    # Convert to Pandas DataFrame
    df = pd.DataFrame(rows, columns=[column[0] for column in cursor.description])

    # Set "Date" as the index and parse it as a datetime object
    df.set_index("date", inplace=True)
    df.index = pd.to_datetime(df.index, format = '%Y-%m-%d')
    
    mu = expected_returns.mean_historical_return(df)
    S = risk_models.sample_cov(df)
    
    # Optimize for maximal Sharpe ratio
    ef = EfficientFrontier(mu, S)
    weights = ef.max_sharpe()
    ef.portfolio_performance(verbose=True)

    cleaned_weights = ef.clean_weights()
    print (f'cleaned_weights are {dict(cleaned_weights)}')

    ef.portfolio_performance(verbose=True)
      
    #Finally, let’s convert the weights into actual allocations values (i.e., how many of each stock to buy). For our allocation, let’s consider an investment amount of $100,000:
    from pypfopt.discrete_allocation import DiscreteAllocation, get_latest_prices

    latest_prices = get_latest_prices(df)

    da = DiscreteAllocation(weights, latest_prices, total_portfolio_value=10000)
    allocation, leftover = da.greedy_portfolio()
    print("Discrete allocation:", allocation)
    print("Funds remaining: ${:.2f}".format(leftover))
    print (allocation)  
     
    responses=cleaned_weights
    
    response_body = {
        'application/json': {
            'body': {'response': json.dumps(responses).replace("{","").replace("}","").replace("\"", "")}
        }
    }
        
    action_response = {
        'actionGroup': event['actionGroup'],
        'apiPath': event['apiPath'],
        'httpMethod': event['httpMethod'],
        'httpStatusCode': 200,
        'responseBody': response_body
    }

    api_response = {'messageVersion': '1.0', 'response': action_response}
    
    return api_response