import json
import boto3
import logging
from http import HTTPStatus


logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    
    logger.info(event)
    api_path = event['apiPath']
    logger.info('API Path')
    logger.info(api_path)
    event['requestBody']['content']['application/json']['properties']
    
    textInput = ""
    
    if api_path == '/sentiment_analysis':
        textInput = event['requestBody']['content']['application/json']['properties'][0]['value']
    else:
        textInput = ""
    
    logger.info(textInput)
    
    client = boto3.client('comprehend')
    try:
        # Call Comprehend to get sentiment of text input
        response = client.detect_sentiment(
            Text= textInput,
            LanguageCode='en'
        )
        responses={'Sentiment':response['Sentiment'],
           'SentimentScore': response['SentimentScore']}
    except Exception as e:  # Catch all for easier error tracing in logs
        logger.error(e, exc_info=True)
        raise Exception('Error occurred during execution')  # notify failure
    response_body = {
        'application/json': {
            'body': json.dumps(responses)
        }
    }
        
    action_response = {
        'actionGroup': event['actionGroup'],
        'apiPath': event['apiPath'],
        'httpMethod': event['httpMethod'],
        'httpStatusCode': 200,
        'responseBody': response_body
    }

    api_response = {'messageVersion': '1.0', 'response': action_response}
    
    return api_response