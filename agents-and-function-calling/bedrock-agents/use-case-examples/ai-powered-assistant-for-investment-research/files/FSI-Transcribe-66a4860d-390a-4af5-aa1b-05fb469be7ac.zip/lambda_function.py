
import os
import boto3
import uuid
import json
import logging
from http import HTTPStatus

# Load Input Output and Archive bucket names
AUDIOTRANSCRIPTS_SOURCE_BUCKET= os.getenv("AUDIOTRANSCRIPTS_SOURCE_BUCKET")
AUDIOTRANSCRIPTS_DEST_BUCKET= os.getenv("MULTIMODAL_OUTPUT_BUCKET")
AUDIOTRANSCRIPTS_DEST_BUCKET_PREFIX= os.getenv("AUDIOTRANSCRIPTS_DEST_BUCKET_PREFIX")

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    s3_resource = boto3.resource('s3')
    s3_client = boto3.client('s3')
    # Create list of all Audio Files
    audio_files = s3_resource.Bucket(AUDIOTRANSCRIPTS_SOURCE_BUCKET).objects.all()
    client = boto3.client('transcribe')
    files = []
    # Create transcription job for each .mp3 file in the AUDIOTRANSCRIPTS_SOURCE_BUCKET
    for file in audio_files:
        if '.mp3' in file.key:
            print(file.key)
            audio_file_path = "s3://" + str(AUDIOTRANSCRIPTS_SOURCE_BUCKET) + "/" + file.key
            s3OutputPath = "s3://" + str(AUDIOTRANSCRIPTS_DEST_BUCKET) + "/" + str(AUDIOTRANSCRIPTS_DEST_BUCKET_PREFIX) + "/"
            jobName = file.key.split("/", 1)[1] + '-' + str(uuid.uuid4())
            try:
                # Call Transcribe job 
                response = client.start_transcription_job(
                    TranscriptionJobName=jobName,
                    LanguageCode='en-US',
                    MediaFormat='mp3',
                    Media={
                         'MediaFileUri': audio_file_path
                    },
                    OutputBucketName = str(AUDIOTRANSCRIPTS_DEST_BUCKET) ,
                    OutputKey = str(AUDIOTRANSCRIPTS_DEST_BUCKET_PREFIX) + file.key.replace(".mp3",".txt")
                )
            except Exception as e:  # Catch all for easier error tracing in logs
                logger.error(e, exc_info=True)
                raise Exception('Error occurred during execution')
 
    return {
        'statusCode': HTTPStatus.OK.value,
        'body': json.dumps('Transcribe job(s)  started')
    }