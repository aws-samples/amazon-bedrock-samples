import json
import boto3
import os
import logging
from http import HTTPStatus
from langchain import PromptTemplate,SQLDatabase, LLMChain
from langchain_experimental.sql.base import SQLDatabaseChain
from langchain.prompts.prompt import PromptTemplate
from sqlalchemy import create_engine
from langchain.llms.bedrock import Bedrock

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    
    logger.info(event)
    api_path = event['apiPath']
    logger.info('API Path')
    logger.info(api_path)
    event['requestBody']['content']['application/json']['properties']
    
    textInput = ""
    
    if api_path == '/query_stock':
        textInput = event['requestBody']['content']['application/json']['properties'][0]['value']
    else:
        textInput = ""
    
    logger.info(textInput)
    
    with open ('param.json','r') as f:
        params=json.load(f)
    
    inference_modifier = {'max_tokens_to_sample':512, 
                      "temperature":0,
                        # "stop_sequences":["\n\nQuestion:","\n\nHuman:"] 
                     }

    session = boto3.Session(region_name = 'us-west-2')
    boto3_bedrock = session.client(service_name="bedrock-runtime")

    llm = Bedrock(client=boto3_bedrock, model_id='anthropic.claude-v2', region_name='us-west-2' )
    llm.model_kwargs = inference_modifier
    
    # Modify the following parameters as needed
    table = 'stock_prices'
    
    connathena=f"athena.{params['region']}.amazonaws.com" 
    portathena='443' #Update, if port is different
    schemaathena=params["db"] #from user defined params
    QUERY_BUCKET= os.getenv("QUERY_BUCKET")
    s3stagingathena=f's3://{QUERY_BUCKET}/athenaresults/'#from cfn params
    wkgrpathena='primary'#Update, if workgroup is different
    
    ##  Create the athena connection string
    connection_string = f"awsathena+rest://@{connathena}:{portathena}/{schemaathena}?s3_staging_dir={s3stagingathena}&work_group={wkgrpathena}"
    
    ##  Create the athena  SQLAlchemy engine
    engine_athena = create_engine(connection_string, echo=False)
    dbathena = SQLDatabase(engine_athena)
    logger.info("TABLE_INFO")
    logger.info(dbathena.get_table_info())
    
    _DEFAULT_TEMPLATE ="""
    First, you understand the question being asked of you, then you perform one of two task depending on the information provided to you:
    1. Assuming a role of a SQL developer, generate SQL statements. Only provide the sql statements alone and no additional text.
    2. Assuming the role of an assistant, provide a clear and direct answer to the question.
    
    Assistant: 
    I understand my role and task. I would understand the question and either provide a sql statement or a natural language answer depending on the information I am provided.
    
    Human:    
    Here are certain nuances to questions that you should pay attention to:
    1. If a question ask for "closing prices", it should be the last price at which a stock trades for the given time period. For example if the time period in the question is 2020, then the closing price is the price for the last available date in 2020.
    2. While generating the SQL take into account that each stock is a column in the table
    
    Assistant: 
    Thank you for the clarification. I would treat any questions with "closing prices" as the last price for the given date period.
    
    Human:    
    Here is a schema of a table:
    <schema>
    {table_info}
    </schema>       
    
    When providing your response:   
    1. If "SQLResult" is not provided, your response should only contain the SQL statement as additional non-sql text would cause Athena to throw an error.
    2. If "SQLResult" is provided, your response should be based off the context in "SQLResult" as a financial expert.
    
    Assistant:   
    Yes, if there is not a SQLResult information provided that tells me that I would be only providing SQL statements alone as additional text would cause Amazon Athena to throw an error.
    However, if SQLResult is provided to me, I would only provide answers to the question based off the SQLResult context after understanding the question from a financial experts view.
    
    Human:
    Question: {input}
    SQLQuery:"""
        
    try:
        PROMPT_sql = PromptTemplate(
            input_variables=["input", "table_info"], template=_DEFAULT_TEMPLATE
        )
        
        db_chain = SQLDatabaseChain.from_llm(llm, dbathena, prompt=PROMPT_sql, verbose=True, return_intermediate_steps=False)
        responses=db_chain.run(textInput)
        #responses=db_chain.run(input=textInput, table_info=dbathena.get_table_info(), dialect=dbathena.dialect)
    except Exception as e:  # Catch all for easier error tracing in logs
        logger.error(e, exc_info=True)
        raise Exception('Error occurred during execution')  # notify failure
    
    response_body = {
        'application/json': {
            'body': {'response':responses}
        }
    }
        
    action_response = {
        'actionGroup': event['actionGroup'],
        'apiPath': event['apiPath'],
        'httpMethod': event['httpMethod'],
        'httpStatusCode': 200,
        'responseBody': response_body
    }

    api_response = {'messageVersion': '1.0', 'response': action_response}
    
    return api_response