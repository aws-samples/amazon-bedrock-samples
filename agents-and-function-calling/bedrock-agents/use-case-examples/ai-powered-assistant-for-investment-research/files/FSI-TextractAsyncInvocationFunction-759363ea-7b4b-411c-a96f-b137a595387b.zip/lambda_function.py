import json
import boto3

def lambda_handler(event, context):
    print(event)
    lambda_client = boto3.client('lambda')
    lambda_client.invoke(FunctionName='FSI-TextractProcessingFunction', 
                     InvocationType='Event',
                     Payload='null')
    return {
        'statusCode': 200,
        'body': json.dumps('PDF conversions to text file started using textextract!')
    }
